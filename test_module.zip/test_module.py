# MOD/test_module.py

def main():
    print("MODM: Test module is running!")

print("MODM: Test module loaded.")
